from dataclasses import dataclass
from datetime import date, time
from typing import Optional
from .subject import Subject

@dataclass
class StudySession:
    date: date
    start_time: time
    end_time: time
    subject: Subject
    duration_minutes: int
    study_type: str
    priority: int
    status: str
    reason: Optional[str] = None

    def __post_init__(self):
        if self.duration_minutes <= 0:
            raise ValueError("Duration must be positive")
        if self.priority < 1:
            raise ValueError("Priority must be 1 or higher")
        valid_statuses = {"Planned", "Completed", "Partial", "Missed"}
        if self.status not in valid_statuses:
            raise ValueError(f"Status must be one of {valid_statuses}")
