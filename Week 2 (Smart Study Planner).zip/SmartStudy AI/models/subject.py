from dataclasses import dataclass
from datetime import date

@dataclass
class Subject:
    name: str
    difficulty: int
    knowledge_percent: float
    target_score: float
    importance: int
    exam_date: date

    def __post_init__(self):
        if not (1 <= self.difficulty <= 5):
            raise ValueError("Difficulty must be between 1 and 5")
        if not (1 <= self.importance <= 5):
            raise ValueError("Importance must be between 1 and 5")
        if not (0.0 <= self.knowledge_percent <= 100.0):
            raise ValueError("Knowledge percent must be between 0 and 100")
