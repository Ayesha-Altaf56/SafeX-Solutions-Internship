from dataclasses import dataclass
from datetime import date

@dataclass
class Student:
    name: str
    week_start_date: date
    daily_available_hours: float
    preferred_session_minutes: int
    max_daily_hours: float

    def __post_init__(self):
        if self.daily_available_hours < 0:
            raise ValueError("Daily available hours cannot be negative")
        if self.preferred_session_minutes <= 0:
            raise ValueError("Preferred session minutes must be positive")
        if self.max_daily_hours < self.daily_available_hours:
            raise ValueError("Max daily hours cannot be less than daily available hours")
