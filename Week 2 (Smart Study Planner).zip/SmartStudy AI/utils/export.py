import csv
import io
from typing import List
from models.study_session import StudySession

def export_sessions_to_csv(sessions: List[StudySession]) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date", "Start Time", "End Time", "Subject", "Duration (min)", "Study Type", "Reason", "Status"])
    
    for s in sessions:
        writer.writerow([
            s.date.strftime("%Y-%m-%d"),
            s.start_time.strftime("%H:%M"),
            s.end_time.strftime("%H:%M"),
            s.subject.name,
            s.duration_minutes,
            s.study_type,
            s.reason or "",
            s.status
        ])
        
    return output.getvalue()

def export_sessions_to_ics(sessions: List[StudySession]) -> str:
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//SmartStudy AI//EN"
    ]
    
    for s in sessions:
        # Format: YYYYMMDDTHHMMSS
        dtstart = f"{s.date.strftime('%Y%m%d')}T{s.start_time.strftime('%H%M%S')}"
        dtend = f"{s.date.strftime('%Y%m%d')}T{s.end_time.strftime('%H%M%S')}"
        
        summary = f"{s.subject.name} - {s.study_type}"
        description = f"Reason: {s.reason or 'None'}"
        
        lines.append("BEGIN:VEVENT")
        lines.append(f"DTSTART:{dtstart}")
        lines.append(f"DTEND:{dtend}")
        lines.append(f"SUMMARY:{summary}")
        lines.append(f"DESCRIPTION:{description}")
        lines.append("END:VEVENT")
        
    lines.append("END:VCALENDAR")
    return "\n".join(lines)
