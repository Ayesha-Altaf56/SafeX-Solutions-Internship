import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import date, timedelta
from models.subject import Subject
from models.student import Student
from scheduler.optimizer import generate_weekly_schedule
from scheduler.priority import calculate_priority
from utils.export import export_sessions_to_csv, export_sessions_to_ics

def init_session_state():
    """Initialize Streamlit session state for storing dynamic subjects."""
    if 'subjects' not in st.session_state:
        st.session_state.subjects = []

def add_subject(name, difficulty, knowledge, target, importance, exam_date):
    """Add a newly configured subject to the session state."""
    st.session_state.subjects.append({
        'name': name,
        'difficulty': difficulty,
        'knowledge_percent': knowledge,
        'target_score': target,
        'importance': importance,
        'exam_date': exam_date
    })

def main():
    st.set_page_config(page_title="SmartStudy AI", layout="wide")
    init_session_state()
    
    st.title("🎓 SmartStudy AI")
    st.markdown("Your intelligent study scheduler and planner.")
    
    with st.sidebar:
        st.header("Student Profile")
        student_name = st.text_input("Name", "John Doe")
        week_start = st.date_input("Week Start Date", date.today())
        daily_hours = st.number_input("Daily Available Hours", min_value=1.0, max_value=24.0, value=4.0, step=0.5)
        pref_duration = st.number_input("Preferred Session Duration (mins)", min_value=30, max_value=120, value=90, step=15)
        
        st.divider()
        st.header("📚 Add Subject")
        
        with st.expander("Subject Details", expanded=True):
            s_name = st.text_input("Subject Name")
            
            col_a, col_b = st.columns(2)
            s_diff = col_a.slider("Difficulty", 1, 5, 3, help="1 = Easy, 5 = Hard")
            s_imp = col_b.slider("Importance", 1, 5, 3, help="1 = Low, 5 = High")
            
            s_know = st.slider("Knowledge %", 0.0, 100.0, 50.0, help="Your current understanding")
            s_target = st.slider("Target Score %", 0.0, 100.0, 90.0)
            
            s_exam = st.date_input("Exam Date", date.today() + timedelta(days=14))
            
            if st.button("➕ Add Subject", use_container_width=True):
                if s_name:
                    add_subject(s_name, s_diff, s_know, s_target, s_imp, s_exam)
                    st.success(f"Added {s_name}!")
                else:
                    st.error("Please enter a subject name.")

    # Main area
    if st.session_state.subjects:
        st.subheader("📝 Your Enrolled Subjects")
        df_subs = pd.DataFrame(st.session_state.subjects)
        df_subs_display = df_subs.copy()
        df_subs_display.insert(0, "#", range(1, len(df_subs_display) + 1))
        df_subs_display = df_subs_display.rename(columns={
            'name': 'Subject',
            'difficulty': 'Difficulty',
            'knowledge_percent': 'Knowledge %',
            'target_score': 'Target Score %',
            'importance': 'Importance',
            'exam_date': 'Exam Date'
        })
        st.dataframe(df_subs_display, use_container_width=True, hide_index=True)
        
        if st.button("🚀 Generate Study Plan", type="primary", use_container_width=True):
            # Create Student object
            student = Student(
                name=student_name,
                week_start_date=week_start,
                daily_available_hours=daily_hours,
                preferred_session_minutes=pref_duration,
                max_daily_hours=daily_hours + 2.0  # arbitrary max
            )
            
            # Create Subject objects
            subjects = []
            for s in st.session_state.subjects:
                subjects.append(Subject(
                    name=s['name'],
                    difficulty=s['difficulty'],
                    knowledge_percent=s['knowledge_percent'],
                    target_score=s['target_score'],
                    importance=s['importance'],
                    exam_date=s['exam_date']
                ))
            
            # Calculate priorities to find highest priority and display stats
            priority_data = []
            highest_priority_subj = None
            highest_p_score = -1
            
            for subj in subjects:
                p_score, p_breakdown = calculate_priority(subj, week_start)
                if p_score > highest_p_score:
                    highest_p_score = p_score
                    highest_priority_subj = subj.name
                    
                priority_data.append({
                    "Subject": subj.name,
                    "Priority Score": round(p_score, 1),
                    "Knowledge Gap": round(p_breakdown['knowledge_gap_contribution'], 1),
                    "Urgency": round(p_breakdown['deadline_contribution'], 1),
                    "Difficulty": round(p_breakdown['difficulty_contribution'], 1)
                })
                
            # Generate schedule
            sessions = generate_weekly_schedule(subjects, student, current_date=week_start)
            
            total_avail_hours = daily_hours * 7
            scheduled_hours = sum([s.duration_minutes for s in sessions]) / 60.0
            nearest_exam = min([s.exam_date for s in subjects])
            
            st.divider()
            st.subheader("📊 Dashboard Overview")
            
            col1, col2, col3, col4, col5 = st.columns(5)
            col1.metric("Total Available", f"{total_avail_hours:.1f}h")
            col2.metric("Scheduled", f"{scheduled_hours:.1f}h")
            col3.metric("Subjects", len(subjects))
            col4.metric("Nearest Exam", nearest_exam.strftime("%b %d"))
            col5.metric("Top Priority", highest_priority_subj)
            
            st.divider()
            st.subheader("📅 Weekly Schedule")
            
            if not sessions:
                st.warning("No sessions could be scheduled.")
            else:
                sched_data = []
                for s in sessions:
                    sched_data.append({
                        "Date": s.date.strftime("%Y-%m-%d"),
                        "Start Time": s.start_time.strftime("%H:%M"),
                        "End Time": s.end_time.strftime("%H:%M"),
                        "Subject": s.subject.name,
                        "Duration (min)": s.duration_minutes,
                        "Study Type": s.study_type,
                        "Reason": s.reason
                    })
                
                df_schedule = pd.DataFrame(sched_data)
                df_schedule_display = df_schedule.copy()
                df_schedule_display.insert(0, "#", range(1, len(df_schedule_display) + 1))
                st.dataframe(df_schedule_display, use_container_width=True, hide_index=True)
                
            st.divider()
            st.subheader("Analytics")
            
            col_a, col_b = st.columns(2)
            
            # 1. Study hours by subject
            subject_hours = {}
            for s in sessions:
                subject_hours[s.subject.name] = subject_hours.get(s.subject.name, 0) + (s.duration_minutes / 60)
            df_hours = pd.DataFrame(list(subject_hours.items()), columns=["Subject", "Hours"])
            if not df_hours.empty:
                fig_hours = px.pie(df_hours, values="Hours", names="Subject", title="Study Hours by Subject")
                col_a.plotly_chart(fig_hours, use_container_width=True)
            
            # 2. Priority score by subject
            df_priority = pd.DataFrame(priority_data)
            if not df_priority.empty:
                fig_priority = px.bar(df_priority, x="Subject", y="Priority Score", title="Priority Score by Subject", color="Subject")
                col_b.plotly_chart(fig_priority, use_container_width=True)
            
            # 3. Available vs Scheduled hours by day
            daily_scheduled = {}
            for s in sessions:
                d_str = s.date.strftime("%Y-%m-%d")
                daily_scheduled[d_str] = daily_scheduled.get(d_str, 0) + (s.duration_minutes / 60)
            
            for i in range(7):
                d_str = (week_start + timedelta(days=i)).strftime("%Y-%m-%d")
                if d_str not in daily_scheduled:
                    daily_scheduled[d_str] = 0.0
                    
            df_daily = pd.DataFrame([
                {"Date": d, "Type": "Scheduled", "Hours": daily_scheduled[d]} for d in daily_scheduled
            ] + [
                {"Date": d, "Type": "Available", "Hours": daily_hours} for d in daily_scheduled
            ])
            
            fig_daily = px.bar(df_daily, x="Date", y="Hours", color="Type", barmode="group", title="Available vs Scheduled Hours by Day")
            st.plotly_chart(fig_daily, use_container_width=True)
            
            st.divider()
            st.subheader("Priority Analysis")
            df_priority_display = df_priority.copy()
            df_priority_display.insert(0, "#", range(1, len(df_priority_display) + 1))
            st.dataframe(df_priority_display, use_container_width=True, hide_index=True)
            
            st.divider()
            st.subheader("Export Schedule")
            
            csv_data = export_sessions_to_csv(sessions)
            ics_data = export_sessions_to_ics(sessions)
            
            col_dl1, col_dl2 = st.columns(2)
            col_dl1.download_button(
                label="Download as CSV",
                data=csv_data,
                file_name="study_schedule.csv",
                mime="text/csv"
            )
            col_dl2.download_button(
                label="Download as ICS (Calendar)",
                data=ics_data,
                file_name="study_schedule.ics",
                mime="text/calendar"
            )
            
    else:
        st.info("👈 Add some subjects in the sidebar to generate a study plan!")

if __name__ == "__main__":
    main()
