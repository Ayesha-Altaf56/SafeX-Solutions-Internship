import pytest
from datetime import date, time
from models import Subject, Student, StudySession

def test_subject_creation():
    subject = Subject(
        name="Math",
        difficulty=4,
        knowledge_percent=75.0,
        target_score=90.0,
        importance=5,
        exam_date=date(2026, 12, 1)
    )
    assert subject.name == "Math"
    assert subject.difficulty == 4

def test_student_creation():
    student = Student(
        name="Alice",
        week_start_date=date(2026, 8, 17),
        daily_available_hours=4.0,
        preferred_session_minutes=60,
        max_daily_hours=6.0
    )
    assert student.name == "Alice"

def test_study_session_creation():
    subject = Subject(
        name="Physics",
        difficulty=5,
        knowledge_percent=50.0,
        target_score=85.0,
        importance=4,
        exam_date=date(2026, 11, 15)
    )
    session = StudySession(
        date=date(2026, 8, 18),
        start_time=time(14, 0),
        end_time=time(15, 0),
        subject=subject,
        duration_minutes=60,
        study_type="Review",
        priority=1,
        status="Planned"
    )
    assert session.duration_minutes == 60
    assert session.status == "Planned"
