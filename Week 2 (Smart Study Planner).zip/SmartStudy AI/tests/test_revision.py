import pytest
from datetime import date, timedelta, time
from models.subject import Subject
from models.study_session import StudySession
from scheduler.revision import schedule_reviews, process_session_completion, process_missed_session

@pytest.fixture
def sample_subject():
    return Subject("Math", 5, 50.0, 90.0, 5, date.today() + timedelta(days=20))

@pytest.fixture
def sample_session(sample_subject):
    return StudySession(
        date=date.today(),
        start_time=time(9, 0),
        end_time=time(10, 0),
        subject=sample_subject,
        duration_minutes=60,
        study_type="Learning",
        priority=100,
        status="Completed"
    )

def test_schedule_reviews(sample_session):
    reviews = schedule_reviews(sample_session)
    # Should schedule at +1, +3, +7, and +19 (exam - 1)
    base_date = sample_session.date
    assert len(reviews) == 4
    assert base_date + timedelta(days=1) in reviews
    assert base_date + timedelta(days=3) in reviews
    assert base_date + timedelta(days=7) in reviews
    assert sample_session.subject.exam_date - timedelta(days=1) in reviews

def test_schedule_reviews_close_exam():
    # Exam in 2 days
    subject = Subject("Math", 5, 50.0, 90.0, 5, date.today() + timedelta(days=2))
    session = StudySession(
        date=date.today(),
        start_time=time(9, 0),
        end_time=time(10, 0),
        subject=subject,
        duration_minutes=60,
        study_type="Learning",
        priority=100,
        status="Completed"
    )
    reviews = schedule_reviews(session)
    # Should only schedule +1 day (which is also exam_date - 1)
    assert len(reviews) == 1
    assert reviews[0] == date.today() + timedelta(days=1)

def test_process_session_completion(sample_session):
    original_knowledge = sample_session.subject.knowledge_percent
    # confidence 4 -> +10.0%
    new_priority = process_session_completion(sample_session, confidence=4, current_date=date.today())
    assert sample_session.subject.knowledge_percent == original_knowledge + 10.0
    assert new_priority > 0

def test_process_missed_session():
    subject = Subject("Math", 5, 50.0, 90.0, 5, date.today() + timedelta(days=20))
    
    missed = StudySession(
        date=date.today(),
        start_time=time(9, 0),
        end_time=time(10, 0),
        subject=subject,
        duration_minutes=30,
        study_type="Learning",
        priority=100,
        status="Missed"
    )
    
    future1 = StudySession(
        date=date.today() + timedelta(days=1),
        start_time=time(9, 0),
        end_time=time(10, 0),
        subject=subject,
        duration_minutes=60,
        study_type="Learning",
        priority=100,
        status="Planned"
    )
    
    future2 = StudySession(
        date=date.today() + timedelta(days=2),
        start_time=time(9, 0),
        end_time=time(10, 0),
        subject=subject,
        duration_minutes=60,
        study_type="Learning",
        priority=100,
        status="Planned"
    )
    
    schedule = [future1, future2]
    process_missed_session(missed, schedule)
    
    # 30 minutes missed distributed across 2 sessions -> 15 min each
    assert future1.duration_minutes == 75
    assert future2.duration_minutes == 75
