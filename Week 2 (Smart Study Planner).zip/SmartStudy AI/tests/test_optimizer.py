import pytest
from datetime import date, timedelta
from models.subject import Subject
from models.student import Student
from scheduler.optimizer import generate_weekly_schedule, determine_study_type_and_reason

@pytest.fixture
def sample_data():
    student = Student(
        name="John",
        week_start_date=date(2026, 8, 17),
        daily_available_hours=4.0, # 240 mins
        preferred_session_minutes=90,
        max_daily_hours=6.0
    )
    
    subjects = [
        Subject("Math", 5, 50.0, 90.0, 5, date(2026, 9, 1)),
        Subject("History", 2, 70.0, 85.0, 3, date(2026, 10, 1)),
        Subject("Physics", 4, 40.0, 80.0, 4, date(2026, 9, 15))
    ]
    return student, subjects

def test_daily_hours_limit(sample_data):
    student, subjects = sample_data
    sessions = generate_weekly_schedule(subjects, student)
    
    # Check max hours per day
    daily_durations = {}
    for s in sessions:
        daily_durations[s.date] = daily_durations.get(s.date, 0) + s.duration_minutes
        
    for d, duration in daily_durations.items():
        assert duration <= student.daily_available_hours * 60

def test_no_overlapping_sessions_and_breaks(sample_data):
    student, subjects = sample_data
    sessions = generate_weekly_schedule(subjects, student)
    
    # Group by date
    sessions_by_date = {}
    for s in sessions:
        sessions_by_date.setdefault(s.date, []).append(s)
        
    # Check overlaps and breaks
    for d, day_sessions in sessions_by_date.items():
        day_sessions.sort(key=lambda x: x.start_time)
        for i in range(len(day_sessions) - 1):
            s1, s2 = day_sessions[i], day_sessions[i+1]
            assert s1.end_time <= s2.start_time
            
            # If s1 was a long session, check if there is at least a 15 min break
            if s1.duration_minutes >= 60:
                s1_end_dt = date(2026, 1, 1) # arbitrary date to combine with time for math
                from datetime import datetime, timedelta
                s1_end = datetime.combine(s1_end_dt, s1.end_time)
                s2_start = datetime.combine(s1_end_dt, s2.start_time)
                diff = (s2_start - s1_end).total_seconds() / 60
                assert diff >= 15

def test_session_durations(sample_data):
    student, subjects = sample_data
    sessions = generate_weekly_schedule(subjects, student)
    
    for s in sessions:
        assert 30 <= s.duration_minutes <= 90  # Bounded to 90 min max continuous study

def test_subject_distribution_and_daily_cap(sample_data):
    student, subjects = sample_data
    sessions = generate_weekly_schedule(subjects, student)
    
    # Check no subject got more than 3 hours in a single day
    daily_subject_durations = {}
    for s in sessions:
        key = (s.date, s.subject.name)
        daily_subject_durations[key] = daily_subject_durations.get(key, 0) + s.duration_minutes
        
    for k, duration in daily_subject_durations.items():
        # Using 180 + some margin for the last session that pushes it over the edge
        # Wait, the penalty applies AFTER it hits 3.0 (180 mins).
        # So it's possible one session pushes it from 170 to 200 mins.
        # But wait, max session is 90. If it's at 150, the next session is min(90, remaining) -> up to 240 mins max.
        assert duration <= 240 # Mathematically 3 hours + max 1 session.
        # Generally, it shouldn't be much higher. The prompt says "don't schedule more than 3 hours... unless necessary"

def test_study_types():
    current_date = date(2026, 8, 1)
    
    # Low knowledge (30%), far exam (10 days away) -> Learning
    sub1 = Subject("Sub1", 3, 30.0, 80.0, 3, date(2026, 8, 11))
    t1, _ = determine_study_type_and_reason(sub1, current_date)
    assert t1 == "Learning"
    
    # Medium knowledge (50%), 4 days away -> Practice
    sub2 = Subject("Sub2", 3, 50.0, 80.0, 3, date(2026, 8, 5))
    t2, _ = determine_study_type_and_reason(sub2, current_date)
    assert t2 == "Practice"
    
    # High knowledge (80%), 1 day away -> Revision or Mock Test
    sub3 = Subject("Sub3", 3, 80.0, 90.0, 3, date(2026, 8, 2))
    t3, _ = determine_study_type_and_reason(sub3, current_date)
    assert t3 in ["Revision", "Mock Test"]
    
    # Low knowledge (20%), 1 day away -> Must prioritize proximity (Revision or Mock Test)
    sub4 = Subject("Sub4", 3, 20.0, 80.0, 3, date(2026, 8, 2))
    t4, r4 = determine_study_type_and_reason(sub4, current_date)
    assert t4 == "Revision" # From d_types[0] when no intersection
    assert "prioritized over" in r4
