import pytest
import pandas as pd
from streamlit.testing.v1 import AppTest

def test_enrolled_subjects_table_numbering():
    at = AppTest.from_file("app.py", default_timeout=10)
    at.run()
    
    # Initially no subjects enrolled
    assert len(at.dataframe) == 0
    
    # 1. Add 'Data Science'
    at.sidebar.text_input[1].input("Data Science").run()
    at.sidebar.button[0].click().run()
    
    # Main area has Enrolled Subjects dataframe
    df1 = at.dataframe[0].value
    assert "#" in df1.columns
    assert list(df1["#"]) == [1]
    assert list(df1["Subject"]) == ["Data Science"]
    
    # 2. Add 'Ai'
    at.sidebar.text_input[1].input("Ai").run()
    at.sidebar.button[0].click().run()
    
    df2 = at.dataframe[0].value
    assert "#" in df2.columns
    assert list(df2["#"]) == [1, 2]
    assert list(df2["Subject"]) == ["Data Science", "Ai"]
    
    # 3. Add 'Physics'
    at.sidebar.text_input[1].input("Physics").run()
    at.sidebar.button[0].click().run()
    
    df3 = at.dataframe[0].value
    assert list(df3["#"]) == [1, 2, 3]
    assert list(df3["Subject"]) == ["Data Science", "Ai", "Physics"]
    
    # 4. Click '🚀 Generate Study Plan' (in main page)
    at.main.button[0].click().run()
    
    # Verify all rendered dataframes have '#' column starting from 1
    assert len(at.dataframe) >= 3  # Enrolled Subjects, Weekly Schedule, Priority Analysis
    for df_element in at.dataframe:
        df_val = df_element.value
        assert "#" in df_val.columns
        assert list(df_val["#"]) == list(range(1, len(df_val) + 1))

