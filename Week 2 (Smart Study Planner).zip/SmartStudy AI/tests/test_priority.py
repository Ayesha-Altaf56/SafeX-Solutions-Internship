import pytest
from datetime import date, timedelta
from models.subject import Subject
from scheduler.priority import calculate_priority

def test_priority_difficulty():
    subject = Subject("Math", 5, 80.0, 90.0, 5, date.today() + timedelta(days=10))
    priority, breakdown = calculate_priority(subject, date.today())
    assert breakdown["difficulty_score"] == 100.0
    assert breakdown["difficulty_contribution"] == 25.0

def test_priority_urgency():
    # Exam tomorrow
    subject1 = Subject("Physics", 3, 50.0, 80.0, 3, date.today() + timedelta(days=1))
    _, breakdown1 = calculate_priority(subject1, date.today())
    assert breakdown1["deadline_urgency"] == 100.0

    # Exam today
    subject2 = Subject("Physics", 3, 50.0, 80.0, 3, date.today())
    _, breakdown2 = calculate_priority(subject2, date.today())
    assert breakdown2["deadline_urgency"] == 100.0

    # Exam in 10 days
    subject3 = Subject("Physics", 3, 50.0, 80.0, 3, date.today() + timedelta(days=10))
    _, breakdown3 = calculate_priority(subject3, date.today())
    assert breakdown3["deadline_urgency"] < 100.0

def test_priority_knowledge_gap():
    # Gap is 30
    subject = Subject("Chem", 3, 50.0, 80.0, 3, date.today() + timedelta(days=10))
    _, breakdown = calculate_priority(subject, date.today())
    assert breakdown["knowledge_gap"] == 30.0

    # Negative gap -> should be 0
    subject_over = Subject("Chem", 3, 90.0, 80.0, 3, date.today() + timedelta(days=10))
    _, breakdown_over = calculate_priority(subject_over, date.today())
    assert breakdown_over["knowledge_gap"] == 0.0

def test_priority_range():
    # Max possible priority
    subject_max = Subject("Bio", 5, 0.0, 100.0, 5, date.today())
    priority_max, _ = calculate_priority(subject_max, date.today())
    assert priority_max <= 100.0
    assert priority_max >= 0.0

    # Min possible priority
    subject_min = Subject("Bio", 1, 100.0, 0.0, 1, date.today() + timedelta(days=50))
    priority_min, _ = calculate_priority(subject_min, date.today())
    assert priority_min <= 100.0
    assert priority_min >= 0.0

def test_priority_invalid_input():
    with pytest.raises(ValueError):
        # Invalid difficulty
        Subject("Bio", 6, 0.0, 100.0, 5, date.today())
