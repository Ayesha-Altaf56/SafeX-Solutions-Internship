import pytest
from datetime import date, time
from models.subject import Subject
from models.study_session import StudySession
from utils.export import export_sessions_to_csv, export_sessions_to_ics

@pytest.fixture
def sample_sessions():
    subject = Subject("Math", 3, 50.0, 90.0, 3, date(2026, 9, 1))
    return [
        StudySession(
            date=date(2026, 8, 18),
            start_time=time(9, 0),
            end_time=time(10, 30),
            subject=subject,
            duration_minutes=90,
            study_type="Learning",
            priority=100,
            status="Planned",
            reason="Low knowledge"
        )
    ]

def test_export_to_csv(sample_sessions):
    csv_data = export_sessions_to_csv(sample_sessions)
    assert "Date,Start Time,End Time,Subject" in csv_data
    assert "2026-08-18" in csv_data
    assert "09:00" in csv_data
    assert "Math" in csv_data

def test_export_to_ics(sample_sessions):
    ics_data = export_sessions_to_ics(sample_sessions)
    assert "BEGIN:VCALENDAR" in ics_data
    assert "END:VCALENDAR" in ics_data
    assert "BEGIN:VEVENT" in ics_data
    assert "DTSTART:20260818T090000" in ics_data
    assert "DTEND:20260818T103000" in ics_data
    assert "SUMMARY:Math - Learning" in ics_data
    assert "DESCRIPTION:Reason: Low knowledge" in ics_data
