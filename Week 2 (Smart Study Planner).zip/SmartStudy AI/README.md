# SmartStudy AI

## 1. Problem
Students often struggle to manage their time efficiently, especially when facing multiple exams with varying difficulties and personal knowledge levels. Traditional study schedules are static, rigid, and fail to adapt to a student's changing understanding or unexpected schedule changes (like missed sessions).

## 2. Features
- **Dynamic Weekly Scheduler**: Automatically chunks study time based on daily availability, ensuring no subject monopolizes a day.
- **Priority Engine**: Mathematically ranks subjects to study based on urgency, difficulty, knowledge gap, target score, and importance.
- **Intelligent Study Types**: Recommends the specific type of study (Learning, Practice, Revision, Mock Test) based on how far away the exam is and the student's current knowledge.
- **Adaptive Spaced Repetition**: Schedules reviews at specific intervals (+1, +3, +7 days) to reinforce memory.
- **Analytics Dashboard**: Visualizes study hours and priority metrics using interactive Plotly charts.
- **Calendar Export**: Exports the generated schedule to CSV and ICS formats for easy import into Google Calendar or Apple Calendar.

## 3. Technology Stack
- **Language**: Python 3.9+
- **Frontend**: Streamlit
- **Data Manipulation**: Pandas
- **Data Visualization**: Plotly
- **Testing**: Pytest

## 4. Priority Formula
The engine calculates a priority score (normalized to 0-100) using the following weights:
- **Difficulty (25%)**: Scaled linearly (1-5).
- **Deadline Urgency (30%)**: Scaled inversely based on days left (max urgency at <= 1 day).
- **Knowledge Gap (25%)**: The difference between the target score and current knowledge percentage.
- **Importance (10%)**: Scaled linearly (1-5).
- **Target Score (10%)**: The target score percentage.

## 5. Scheduling Algorithm
The optimizer uses a greedy allocation strategy combined with an **effective priority** recalculation:
- `effective_priority = base_priority / (1.0 + allocated_hours)`
- A strong penalty is applied if a subject exceeds 3 hours in a single day to force balanced study.
- Sessions are strictly bounded between 30 and 90 minutes.
- A 15-minute break is automatically appended to any session lasting 60+ minutes.

## 6. Spaced Repetition
Upon completing a session, the system calculates dates for spaced repetition reviews:
- Review 1: +1 day
- Review 2: +3 days
- Review 3: +7 days
- Final Review: 1 day before the exam.
No reviews are scheduled on or after the exam date.

## 7. Adaptive Rescheduling
- **Completed Sessions**: Increase the student's knowledge percent based on a self-reported confidence score (1-5). Priority is then dynamically recalculated.
- **Missed Sessions**: The lost time is evenly redistributed into future planned sessions for that subject, ensuring the student still covers the required material.

## 8. Installation
1. Clone the repository.
2. Create a virtual environment: `python -m venv venv`
3. Activate the environment: `source venv/bin/activate` (Linux/Mac) or `venv\Scripts\activate` (Windows)
4. Install dependencies: `pip install -r requirements.txt`

## 9. Running the App
Run the Streamlit application using the following command:
```bash
streamlit run app.py
```

## 10. Testing
The logic is comprehensively tested using `pytest`.
To run the test suite:
```bash
pytest tests/
```

## 11. Three Example Profiles
Located in `data/profiles.py`:
- **Alice (Profile 1)**: Heavy workload, difficult subjects, close exams. Needs intensive 120-min preferred sessions (capped to 90 by realism bounds) and high urgency allocation.
- **Bob (Profile 2)**: Balanced subjects, moderate difficulty, exams spread out. Standard 60-minute blocks distributed evenly.
- **Charlie (Profile 3)**: Very limited daily study hours (1 hr/day) but several upcoming exams. Highly constrained scheduling requiring strict optimization.

## 12. Future Improvements
- **Integration with Learning Management Systems (LMS)**: Auto-importing exam dates and assignments from Canvas or Blackboard.
- **Machine Learning**: Training a model to personalize the priority weights based on historic student performance.
- **Mobile App**: Creating a React Native frontend for on-the-go schedule tracking.

## 13. University/Business Value
SmartStudy AI offers immense value to educational institutions by providing students with a personalized, stress-reducing planning tool. By optimizing study habits dynamically, it can improve overall student retention, GPA averages, and mental health by eliminating the cognitive load of schedule management.
