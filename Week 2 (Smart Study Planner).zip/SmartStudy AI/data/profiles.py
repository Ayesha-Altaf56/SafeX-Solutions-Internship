from datetime import date, timedelta
from models.student import Student
from models.subject import Subject

def get_profile_1():
    """Heavy workload, difficult subjects, close exams."""
    student = Student(
        name="Alice",
        week_start_date=date.today(),
        daily_available_hours=6.0,
        preferred_session_minutes=120,
        max_daily_hours=8.0
    )
    subjects = [
        Subject("Advanced Calculus", 5, 30.0, 90.0, 5, date.today() + timedelta(days=2)),
        Subject("Quantum Mechanics", 5, 40.0, 85.0, 5, date.today() + timedelta(days=3))
    ]
    return student, subjects

def get_profile_2():
    """Balanced subjects, moderate difficulty, exams spread out."""
    student = Student(
        name="Bob",
        week_start_date=date.today(),
        daily_available_hours=4.0,
        preferred_session_minutes=60,
        max_daily_hours=5.0
    )
    subjects = [
        Subject("History", 3, 60.0, 80.0, 3, date.today() + timedelta(days=15)),
        Subject("Biology", 3, 50.0, 85.0, 4, date.today() + timedelta(days=20)),
        Subject("Art", 2, 70.0, 90.0, 2, date.today() + timedelta(days=25))
    ]
    return student, subjects

def get_profile_3():
    """Very limited daily study hours and several upcoming exams."""
    student = Student(
        name="Charlie",
        week_start_date=date.today(),
        daily_available_hours=1.0,
        preferred_session_minutes=45,
        max_daily_hours=2.0
    )
    subjects = [
        Subject("Physics", 4, 50.0, 80.0, 4, date.today() + timedelta(days=5)),
        Subject("Math", 4, 60.0, 90.0, 5, date.today() + timedelta(days=7)),
        Subject("English", 2, 80.0, 95.0, 3, date.today() + timedelta(days=6))
    ]
    return student, subjects
