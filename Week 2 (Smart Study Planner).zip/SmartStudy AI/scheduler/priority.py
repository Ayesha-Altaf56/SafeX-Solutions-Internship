from datetime import date
from models.subject import Subject
from typing import Dict, Any, Tuple

def calculate_priority(subject: Subject, current_date: date = None) -> Tuple[float, Dict[str, Any]]:
    """
    Calculate the priority of a subject.
    Returns:
        float: Normalized priority score (0-100)
        dict: Breakdown of how each factor contributed.
    """
    if current_date is None:
        current_date = date.today()

    # 1. Difficulty score (normalize 1-5 to 0-100)
    difficulty_score = (subject.difficulty / 5.0) * 100.0

    # 2. Deadline urgency
    days_left = (subject.exam_date - current_date).days
    if days_left <= 1:
        deadline_urgency = 100.0  # Exam is today, tomorrow, or in the past
    else:
        # Scale down urgency based on days left (e.g. 0 at 30 days)
        deadline_urgency = max(0.0, 100.0 - ((days_left - 1) * 3.33)) # roughly 0 at 30 days

    # 3. Knowledge gap
    knowledge_gap = max(0.0, subject.target_score - subject.knowledge_percent)

    # 4. Importance score (normalize 1-5 to 0-100)
    importance_score = (subject.importance / 5.0) * 100.0

    # 5. Target score
    target_score_val = subject.target_score

    # Calculate final priority
    priority = (
        0.25 * difficulty_score +
        0.30 * deadline_urgency +
        0.25 * knowledge_gap +
        0.10 * importance_score +
        0.10 * target_score_val
    )

    # Normalize final score to 0-100
    priority = max(0.0, min(100.0, priority))

    breakdown = {
        "difficulty_score": difficulty_score,
        "difficulty_contribution": 0.25 * difficulty_score,
        "deadline_urgency": deadline_urgency,
        "deadline_contribution": 0.30 * deadline_urgency,
        "knowledge_gap": knowledge_gap,
        "knowledge_gap_contribution": 0.25 * knowledge_gap,
        "importance_score": importance_score,
        "importance_contribution": 0.10 * importance_score,
        "target_score": target_score_val,
        "target_score_contribution": 0.10 * target_score_val
    }

    return priority, breakdown
