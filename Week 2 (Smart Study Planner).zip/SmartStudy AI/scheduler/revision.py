from datetime import date, timedelta
from typing import List, Tuple
from models.study_session import StudySession
from models.subject import Subject
from scheduler.priority import calculate_priority

def schedule_reviews(completed_session: StudySession) -> List[date]:
    """
    Schedule future reviews after a completed session: +1 day, +3 days, +7 days, and before exam.
    Never schedule after the exam.
    """
    if completed_session.status != "Completed":
        return []
        
    base_date = completed_session.date
    exam_date = completed_session.subject.exam_date
    
    review_offsets = [1, 3, 7]
    review_dates = []
    
    # Standard intervals
    for offset in review_offsets:
        target_date = base_date + timedelta(days=offset)
        if target_date < exam_date:
            review_dates.append(target_date)
            
    # Final review (1 day before exam)
    final_review = exam_date - timedelta(days=1)
    if final_review > base_date and final_review not in review_dates:
        review_dates.append(final_review)
        
    return sorted(review_dates)

def process_session_completion(session: StudySession, confidence: int = None, current_date: date = None) -> float:
    """
    Process a completed session, increasing knowledge based on confidence 1-5.
    Returns the newly calculated priority.
    """
    if current_date is None:
        current_date = date.today()
        
    subject = session.subject
    
    if session.status == "Completed":
        confidence = confidence or 3 # Default confidence
        # E.g., confidence 1 -> +2.5%, confidence 5 -> +12.5%
        increase = confidence * 2.5
        subject.knowledge_percent = min(100.0, subject.knowledge_percent + increase)
        
    new_priority, _ = calculate_priority(subject, current_date)
    return new_priority

def process_missed_session(missed_session: StudySession, future_schedule: List[StudySession]):
    """
    Redistribute missed session time across future available days for the same subject.
    Modifies the future_schedule in-place.
    """
    if missed_session.status != "Missed":
        return
        
    subject_name = missed_session.subject.name
    missed_minutes = missed_session.duration_minutes
    
    # Find all future Planned sessions for this subject
    future_sessions = [s for s in future_schedule 
                       if s.subject.name == subject_name and s.status == "Planned" and s.date > missed_session.date]
                       
    if not future_sessions:
        return # Cannot distribute if no future sessions exist in the window
        
    # Distribute evenly
    added_per_session = missed_minutes // len(future_sessions)
    remainder = missed_minutes % len(future_sessions)
    
    for idx, session in enumerate(future_sessions):
        extra = added_per_session + (1 if idx < remainder else 0)
        # Cap session to 90 mins max
        if session.duration_minutes + extra <= 90:
            session.duration_minutes += extra
        else:
            # Add up to 90, remainder is lost or could be handled in a while loop
            session.duration_minutes = 90 
