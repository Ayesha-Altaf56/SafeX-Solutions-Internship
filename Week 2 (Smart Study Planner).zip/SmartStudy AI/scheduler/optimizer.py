from datetime import date, datetime, timedelta, time
from typing import List, Tuple
from models.subject import Subject
from models.student import Student
from models.study_session import StudySession
from scheduler.priority import calculate_priority

def determine_study_type_and_reason(subject: Subject, current_date: date) -> Tuple[str, str]:
    days_left = (subject.exam_date - current_date).days
    knowledge = subject.knowledge_percent
    
    if knowledge < 40.0:
        k_types = ["Learning"]
        k_reason = "Knowledge is below 40%"
    elif knowledge <= 70.0:
        k_types = ["Learning", "Practice"]
        k_reason = "Knowledge is between 40% and 70%"
    else:
        k_types = ["Practice", "Revision"]
        k_reason = "Knowledge is above 70%"
        
    if days_left >= 7:
        d_types = ["Learning", "Practice"]
        d_reason = "Exam is 7+ days away"
    elif days_left >= 3:
        d_types = ["Practice", "Revision"]
        d_reason = "Exam is 3-6 days away"
    else:
        d_types = ["Revision", "Mock Test"]
        d_reason = "Exam is within 2 days"
        
    intersection = set(k_types).intersection(set(d_types))
    
    if intersection:
        selected_type = [t for t in k_types if t in intersection][0]
        reason = f"{k_reason} and {d_reason}."
    else:
        selected_type = d_types[0]
        reason = f"{d_reason} (prioritized over {k_reason})."
        
    return selected_type, reason

def generate_weekly_schedule(subjects: List[Subject], student: Student, current_date: date = None) -> List[StudySession]:
    """
    Generate a weekly schedule for a given student and their subjects.
    
    Rules:
    - Schedules study sessions for 7 days starting from student.week_start_date
    - Uses priority engine to rank subjects
    - Dynamically recalculates effective priority: base_priority / (1 + allocated_hours)
    - Session duration is bounded by 30-120 minutes and student preferences
    - No overlapping sessions on any given day
    """
    if current_date is None:
        current_date = date.today()
        
    start_date = student.week_start_date
    daily_hours = student.daily_available_hours
    preferred_duration_min = student.preferred_session_minutes
    
    # Clamp preferred duration to the allowed 30-90 range
    preferred_duration_min = max(30, min(90, preferred_duration_min))
    
    # Calculate initial priorities for all subjects
    base_priorities = {}
    for s in subjects:
        p, _ = calculate_priority(s, current_date)
        base_priorities[s.name] = p
        
    allocated_hours = {s.name: 0.0 for s in subjects}
    sessions = []
    
    # Schedule for 7 days
    for day_offset in range(7):
        current_day = start_date + timedelta(days=day_offset)
        remaining_minutes = int(daily_hours * 60)
        
        # Track daily subject hours to prevent studying one subject too much in a single day
        daily_subject_hours = {s.name: 0.0 for s in subjects}
        
        # Start studying at 09:00 AM each day
        current_time = datetime.combine(current_day, time(9, 0))
        
        while remaining_minutes >= 30:
            # Recalculate effective priority to avoid starving subjects
            best_subject = None
            best_effective = -1.0
            
            for s in subjects:
                # Formula: effective_priority = priority / (1 + allocated_hours)
                effective = base_priorities[s.name] / (1.0 + allocated_hours[s.name])
                
                # Apply strong penalty if subject has already been studied for 3+ hours today
                if daily_subject_hours[s.name] >= 3.0:
                    effective /= 100.0
                    
                if effective > best_effective:
                    best_effective = effective
                    best_subject = s
                    
            if not best_subject:
                break
                
            # Determine how long this session will be
            duration_minutes = min(preferred_duration_min, remaining_minutes, 90)
            
            if duration_minutes < 30:
                break
                
            end_time = current_time + timedelta(minutes=duration_minutes)
            
            # Create session
            study_type, reason = determine_study_type_and_reason(best_subject, current_day)
            
            session = StudySession(
                date=current_day,
                start_time=current_time.time(),
                end_time=end_time.time(),
                subject=best_subject,
                duration_minutes=duration_minutes,
                study_type=study_type,
                priority=int(base_priorities[best_subject.name]),
                status="Planned",
                reason=reason
            )
            sessions.append(session)
            
            # Update tracking metrics
            allocated_hours[best_subject.name] += (duration_minutes / 60.0)
            daily_subject_hours[best_subject.name] += (duration_minutes / 60.0)
            remaining_minutes -= duration_minutes
            current_time = end_time
            
            # Add a 15-minute break after a long session
            if duration_minutes >= 60:
                current_time += timedelta(minutes=15)
            
    return sessions
