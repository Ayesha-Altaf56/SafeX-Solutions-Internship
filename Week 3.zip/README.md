# CyberMail AI
AI-Powered Email Triage for Cybersecurity Teams

## Problem
Cybersecurity support inboxes receive mixed emails including urgent security incidents, support requests, potential sales leads, and spam. Manual sorting can delay important responses.

## Solution
CyberMail AI uses Google Gemini to analyze incoming email content and classify it into:
- Urgent
- Support
- Sales
- Spam

## Features
- AI email classification
- Confidence score
- Priority level
- Classification reasoning
- AI-generated suggested replies
- Batch CSV classification
- CSV results download
- Professional Streamlit dashboard
- Error handling and input validation

## Technology Stack
- Python
- Streamlit
- Google Gemini API
- Pandas
- python-dotenv

## Project Structure
- `app.py` - The main Streamlit web application dashboard and UI logic.
- `classifier.py` - Core logic for connecting to the Gemini API and processing single emails.
- `batch_processor.py` - Logic for iterating through datasets and classifying batches.
- `prompts.py` - Contains the system prompts guiding the AI classification logic.
- `requirements.txt` - Project dependencies.
- `.env` - (Not tracked) Stores environment variables like the API key.
- `.gitignore` - Git ignore rules.
- `data/` - Directory for storing sample data or CSV inputs.
- `screenshots/` - Directory for storing application preview images.

## Installation
To run CyberMail AI locally, follow these steps:

1. Create a virtual environment:
   ```bash
   python -m venv .venv
   ```

2. Activate the virtual environment and install dependencies:
   ```bash
   .\.venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Create a `.env` file in the root directory and add your Google Gemini API key:
   ```env
   GEMINI_API_KEY=your_api_key_here
   ```

4. Run the Streamlit application:
   ```bash
   .\.venv\Scripts\python.exe -m streamlit run app.py
   ```

## CSV Format
When using the **Batch Analysis** feature, your uploaded CSV file **must** require an `email` column containing the email content for each row. The AI will classify each email and generate an enriched dataset containing the newly appended metrics.

## Security
- API keys are securely stored in a local `.env` file, which is actively excluded from source control using `.gitignore` to prevent credential leaks.
- Note: Synthetic or test emails should be used for demonstrations instead of sensitive real client data.

## Limitations
- **Internet Dependency:** Requires an active internet connection to communicate with Google's API.
- **API Availability:** Depends on Gemini API availability and is subject to rate limits.
- **Human Review:** AI classifications should always be reviewed by a human for critical security incidents.
- **MVP Status:** This is a Minimum Viable Product (MVP) and does not directly connect to live, production email systems.

## Testing
- **Single-Email Classification:** Manually entered a range of random, varied emails into the classifier to verify that the category, confidence score, priority level, and reasoning output all made sense.
- **Batch Processing:** Uploaded a CSV file containing multiple emails through the batch classification feature, confirming that every row was processed correctly and a downloadable results CSV was generated successfully.

## Skills Learned
- **Prompt Engineering:** Designed strict system prompts to instruct the Gemini API to consistently return highly structured, valid classification outputs.
- **LLM API Integration:** Connected and authenticated the `google-genai` Python SDK to send dynamic user inputs to the Gemini model.
- **Frontend Development:** Built an interactive, responsive Streamlit dashboard featuring custom CSS, dynamic metric cards, and seamless file upload/download flows.
- **Data Processing:** Leveraged Pandas for batch CSV reading, row-by-row DataFrame manipulation, and safely exporting enriched datasets.

## Challenges & Solutions
- **Structured LLM Output:** Getting Gemini to return consistent, parseable JSON rather than free-form conversational text is notoriously difficult. **Solution:** Enforced strict prompt instructions in `prompts.py`, utilized the `response_mime_type="application/json"` config parameter, and wrote custom cleanup logic in `classifier.py` to strip out markdown blocks and apply programmatic fallback values if the model hallucinated invalid categories.
- **Batch Processing Resilience:** A single API failure or malformed row could crash an entire batch CSV job. **Solution:** Implemented row-level `try...except` blocks in `batch_processor.py` that gracefully catch errors, mark the specific row as an "error" in the DataFrame, and allow the rest of the dataset to continue processing uninterrupted.

## Future Improvements
- Gmail/Outlook API integration
- Authentication and user accounts
- Incident tracking and automated ticketing
- Advanced analytics and reporting
- Improved evaluation datasets
