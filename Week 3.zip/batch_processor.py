import pandas as pd
from classifier import classify_email

def process_batch(df: pd.DataFrame) -> pd.DataFrame:
    """
    Classifies a batch of emails inside a pandas DataFrame.
    
    Args:
        df: A pandas DataFrame containing an 'email' column.
        
    Returns:
        The updated DataFrame with classification columns added.
    """
    if "email" not in df.columns:
        raise ValueError("The provided DataFrame must contain an 'email' column.")
        
    # Ensure new columns exist
    new_columns = ["category", "confidence", "priority", "reason", "suggested_reply"]
    for col in new_columns:
        if col not in df.columns:
            df[col] = None
            
    for index, row in df.iterrows():
        email_text = row["email"]
        
        # Skip empty emails
        if pd.isna(email_text) or not str(email_text).strip():
            continue
            
        try:
            result = classify_email(str(email_text))
            
            if "error" in result:
                # Handle API/parsing errors returned by classify_email
                df.at[index, "reason"] = f"Error: {result['error']}"
                df.at[index, "category"] = "error"
            else:
                df.at[index, "category"] = result.get("category", "")
                df.at[index, "confidence"] = result.get("confidence", 0)
                df.at[index, "priority"] = result.get("priority", "")
                df.at[index, "reason"] = result.get("reason", "")
                df.at[index, "suggested_reply"] = result.get("suggested_reply", "")
                
        except Exception as e:
            # Catch unexpected row-level exceptions to prevent full batch crashes
            df.at[index, "reason"] = f"Unhandled Exception: {str(e)}"
            df.at[index, "category"] = "error"
            
    return df
