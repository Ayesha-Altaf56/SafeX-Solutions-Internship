import os
import json
from dotenv import load_dotenv
from google import genai
from google.genai import types

from prompts import SYSTEM_PROMPT

# Load environment variables from .env file
load_dotenv()

# Initialize the Gemini client using the API key from the environment
api_key = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=api_key)

VALID_CATEGORIES = {"urgent", "support", "sales", "spam"}
VALID_PRIORITIES = {"critical", "high", "medium", "low"}

def classify_email(email_text):
    """
    Classifies the given email text into one of the predefined categories.
    Returns the parsed Python dictionary containing the results.
    """
    try:
        response = client.models.generate_content(
            model='gemini-3.6-flash',
            contents=email_text,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                response_mime_type="application/json",
            )
        )
        
        raw_text = response.text
        
        # Clean up markdown JSON block if present
        clean_text = raw_text.strip()
        if clean_text.startswith("```json"):
            clean_text = clean_text[7:]
        elif clean_text.startswith("```"):
            clean_text = clean_text[3:]
            
        if clean_text.endswith("```"):
            clean_text = clean_text[:-3]
            
        # Parse JSON
        data = json.loads(clean_text.strip())
        
        # Validate category
        category = data.get("category", "")
        if category not in VALID_CATEGORIES:
            data["category"] = "support"  # Fallback to support
            
        # Validate confidence
        confidence = data.get("confidence", 0)
        if not isinstance(confidence, int) or not (0 <= confidence <= 100):
            data["confidence"] = 0
            
        # Validate priority
        priority = data.get("priority", "")
        if priority not in VALID_PRIORITIES:
            data["priority"] = "medium" # Fallback to medium
            
        return data

    except json.JSONDecodeError as e:
        return {"error": f"Failed to parse model response as JSON: {e}\nRaw output: {raw_text}"}
    except Exception as e:
        return {"error": f"API Error: {str(e)}"}
