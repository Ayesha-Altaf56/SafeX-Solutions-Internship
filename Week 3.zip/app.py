import streamlit as st
import pandas as pd
from io import BytesIO
from classifier import classify_email
from batch_processor import process_batch

# Must be the first Streamlit command
st.set_page_config(page_title="CyberMail AI", page_icon="🛡️", layout="wide")

# Custom CSS for dark cybersecurity SaaS theme
st.markdown("""
<style>
    /* Hide default Streamlit UI elements */
    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
    footer {visibility: hidden;}

    /* Global styling */
    .stApp {
        background-color: #0b0f19;
        color: #94a3b8;
        font-family: 'Inter', -apple-system, sans-serif;
    }
    
    /* Typography */
    h1, h2, h3, h4, h5, h6 {
        color: #e2e8f0;
        font-weight: 500;
        letter-spacing: -0.01em;
        margin-bottom: 0.5rem;
    }
    
    .text-muted { color: #94a3b8; }
    .text-sm { font-size: 0.85rem; }
    .text-xs { font-size: 0.75rem; }
    
    /* Neon accents */
    .text-blue { color: #38bdf8; }
    .text-purple { color: #a855f7; }
    
    /* Text Area & File Uploader Styling */
    .stTextArea > label, .stFileUploader > label { display: none !important; }
    .stTextArea textarea {
        background-color: #0f172a;
        color: #cbd5e1;
        border: 1px solid #1e293b;
        border-radius: 6px;
        padding: 1rem;
        font-size: 0.95rem;
        line-height: 1.5;
        transition: all 0.2s ease;
        box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
    }
    .stTextArea textarea:focus {
        border-color: #475569;
        box-shadow: inset 0 2px 4px rgba(0,0,0,0.1), 0 0 0 1px #475569;
    }
    
    /* Button Styling */
    .stButton > button, .stDownloadButton > button {
        background-color: #1e293b;
        color: #f8fafc;
        border: 1px solid #334155;
        border-radius: 6px;
        padding: 0.6rem 1.2rem;
        font-weight: 500;
        font-size: 0.95rem;
        transition: all 0.2s ease;
        width: 100%;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    .stButton > button:hover, .stDownloadButton > button:hover {
        background-color: #38bdf8;
        border-color: #38bdf8;
        color: #082f49;
        transform: translateY(-1px);
        box-shadow: 0 4px 6px rgba(56, 189, 248, 0.15);
    }
    
    /* Cards */
    .card {
        background-color: #111827;
        border: 1px solid #1e293b;
        border-radius: 8px;
        padding: 1.25rem;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }
    
    /* Metrics Row */
    .metrics-container {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        flex: 1;
        min-width: 140px;
        background-color: #111827;
        border: 1px solid #1e293b;
        border-radius: 8px;
        padding: 1.25rem;
    }
    .metric-label {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #94a3b8;
        margin-bottom: 0.5rem;
    }
    .metric-value {
        font-size: 1.5rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    /* Progress Bar */
    .progress-bg {
        width: 100%;
        background-color: #1e293b;
        height: 6px;
        border-radius: 3px;
        margin-top: 0.75rem;
        overflow: hidden;
    }
    .progress-fill {
        height: 100%;
        border-radius: 3px;
        transition: width 0.5s ease;
    }
    
    /* Workflow Stepper */
    .workflow-container {
        display: flex;
        justify-content: space-between;
        position: relative;
        margin-top: 1rem;
    }
    .workflow-line {
        position: absolute;
        top: 1.25rem;
        left: 10%;
        right: 10%;
        height: 2px;
        background-color: #334155;
        z-index: 0;
    }
    .workflow-step {
        flex: 1;
        text-align: center;
        z-index: 1;
        padding: 0 0.5rem;
    }
    .step-circle {
        width: 2.5rem;
        height: 2.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        margin: 0 auto 0.75rem auto;
        border: 4px solid #0b0f19;
    }
    
    /* Miscellaneous */
    hr {
        border-color: #1e293b !important;
        margin: 1.5rem 0 !important;
    }
    .stCodeBlock {
        border-radius: 6px !important;
        border: 1px solid #1e293b !important;
    }
</style>
""", unsafe_allow_html=True)


# Layout: Left for input, Right for results
left_col, right_col = st.columns([1, 2], gap="large")

with left_col:
    st.markdown('<h2 style="margin-bottom: 0;">CyberMail <span class="text-blue">AI</span> 🛡️</h2>', unsafe_allow_html=True)
    st.markdown('<p class="text-muted text-sm" style="margin-top: -5px; margin-bottom: 20px;">AI-Powered Email Triage</p>', unsafe_allow_html=True)
    
    st.markdown("### Navigation")
    app_mode = st.radio("Mode", ["Analyze Email", "Batch Analysis"], label_visibility="collapsed")
    st.markdown("<hr>", unsafe_allow_html=True)

    if app_mode == "Analyze Email":
        st.markdown("### 📥 Email Content")
        email_text = st.text_area("Email Content", label_visibility="collapsed", height=280, placeholder="Paste suspicious or routine email here for immediate analysis...")
        st.caption(f"Character count: {len(email_text)}")
        
        analyze_btn = st.button("Analyze Email", type="primary")
        
        st.markdown("<p class='text-muted text-xs' style='margin-top: 10px;'>🔒 Processed securely. No permanent logs.</p>", unsafe_allow_html=True)
        
        st.markdown("""
        <div class="card">
            <h5 class="text-blue" style="margin-top: 0; margin-bottom: 8px;">💡 Pro Tips</h5>
            <ul class="text-muted text-sm" style="padding-left: 20px; margin-bottom: 0;">
                <li>Include email headers for better context.</li>
                <li>Obfuscate sensitive PII before pasting.</li>
                <li>Look out for urgent requests in the reasoning.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    elif app_mode == "Batch Analysis":
        st.markdown("### 📂 Upload Batch (CSV)")
        uploaded_file = st.file_uploader("Upload CSV", type=["csv"], label_visibility="collapsed")
        
        if uploaded_file is not None:
            current_file_key = f"{uploaded_file.name}_{uploaded_file.size}"
            if "uploaded_file_key" not in st.session_state or st.session_state.uploaded_file_key != current_file_key:
                try:
                    uploaded_file.seek(0)
                    st.session_state.uploaded_df = pd.read_csv(uploaded_file)
                    st.session_state.uploaded_file_key = current_file_key
                except pd.errors.EmptyDataError:
                    st.session_state.uploaded_df = "empty"
                    st.session_state.uploaded_file_key = current_file_key
                except Exception:
                    st.session_state.uploaded_df = "error"
                    st.session_state.uploaded_file_key = current_file_key
                    
            df_status = st.session_state.uploaded_df
            
            if isinstance(df_status, str):
                if df_status == "empty":
                    st.error("The uploaded CSV is empty or invalid.")
                else:
                    st.error("Invalid CSV format.")
                batch_btn = None
            else:
                if df_status.empty:
                    st.error("The uploaded CSV has no data rows.")
                    batch_btn = None
                elif "email" not in df_status.columns:
                    st.error("Invalid CSV: Must contain an 'email' column.")
                    batch_btn = None
                else:
                    st.caption(f"Rows detected: {len(df_status)}")
                    st.success("Valid CSV format.")
                    batch_btn = st.button("Classify Batch", type="primary")
        else:
            batch_btn = None
            st.info("Upload a CSV file containing an 'email' column.")
            st.session_state.pop("uploaded_df", None)
            st.session_state.pop("uploaded_file_key", None)
            
        st.markdown("<p class='text-muted text-xs' style='margin-top: 10px;'>🔒 Batch processing runs locally and via secure API endpoints.</p>", unsafe_allow_html=True)

with right_col:
    if app_mode == "Analyze Email":
        st.markdown("### 🔬 Analysis Dashboard")
        
        if "analysis_result" not in st.session_state:
            st.session_state.analysis_result = None

        if analyze_btn:
            if not email_text.strip():
                st.warning("Please enter an email to analyze.")
                st.session_state.analysis_result = None
            else:
                with st.spinner("Analyzing email threat vectors..."):
                    st.session_state.analysis_result = classify_email(email_text)
                    
        if st.session_state.analysis_result is not None:
            result = st.session_state.analysis_result
            if "error" in result:
                st.error(result["error"])
            else:
                st.markdown("""
                <div style="background-color: #064e3b; color: #34d399; padding: 12px 16px; border-radius: 6px; margin-bottom: 1.5rem; border: 1px solid #059669; display: flex; align-items: center; font-size: 0.95rem;">
                    <span style="font-size: 1.2rem; margin-right: 10px;">✅</span>
                    <strong>Analysis Complete:</strong>&nbsp;Threat vectors assessed successfully.
                </div>
                """, unsafe_allow_html=True)
                
                category = result.get("category", "support").lower()
                priority = result.get("priority", "medium").lower()
                confidence = result.get("confidence", 0)
                
                # Determine colors
                color_map = {
                    "urgent": "#ef4444", "critical": "#ef4444",
                    "high": "#f97316",
                    "support": "#38bdf8", "medium": "#38bdf8", "normal": "#38bdf8",
                    "sales": "#a855f7",
                    "spam": "#94a3b8", "low": "#94a3b8"
                }
                cat_color = color_map.get(category, "#38bdf8")
                pri_color = color_map.get(priority, "#38bdf8")
                conf_color = "#10b981" if confidence >= 80 else ("#f59e0b" if confidence >= 50 else "#ef4444")
                
                icon_map = {
                    "urgent": "🚨", "critical": "🚨",
                    "high": "⚠️",
                    "support": "🛠️", "medium": "ℹ️",
                    "sales": "💼",
                    "spam": "🗑️", "low": "🔽"
                }
                cat_icon = icon_map.get(category, "📌")
                pri_icon = icon_map.get(priority, "📌")
                
                st.markdown(f"""
                <div class="metrics-container">
                    <div class="metric-card" style="border-top: 3px solid {cat_color};">
                        <div class="metric-label">Category</div>
                        <div class="metric-value" style="color: {cat_color};">
                            <span>{cat_icon}</span> <span>{category.title()}</span>
                        </div>
                    </div>
                    <div class="metric-card" style="border-top: 3px solid {pri_color};">
                        <div class="metric-label">Priority</div>
                        <div class="metric-value" style="color: {pri_color};">
                            <span>{pri_icon}</span> <span>{priority.title()}</span>
                        </div>
                    </div>
                    <div class="metric-card" style="border-top: 3px solid {conf_color};">
                        <div class="metric-label">Confidence</div>
                        <div class="metric-value" style="color: {conf_color};">
                            <span>🎯</span> <span>{confidence}%</span>
                        </div>
                        <div class="progress-bg">
                            <div class="progress-fill" style="width: {confidence}%; background-color: {conf_color};"></div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                reason = result.get("reason", "No reason provided.")
                st.markdown(f"""
                <div class="card" style="border-left: 4px solid #a855f7;">
                    <h4 style="display: flex; align-items: center; gap: 8px;">
                        <span style="color: #a855f7;">ℹ️</span> Detection Reasoning
                    </h4>
                    <div style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.5;">{reason}</div>
                </div>
                """, unsafe_allow_html=True)
                
                suggested_reply = result.get("suggested_reply", "").strip()
                if category == "spam" or not suggested_reply:
                    suggested_reply_text = "No reply recommended."
                else:
                    suggested_reply_text = suggested_reply
                    
                st.markdown(f"""
                <div class="card" style="border-left: 4px solid #38bdf8; margin-bottom: 0.5rem;">
                    <h4 style="display: flex; align-items: center; gap: 8px;">
                        <span style="color: #38bdf8;">✉️</span> Suggested Reply
                    </h4>
                    <div class="text-muted text-sm" style="margin-bottom: 12px;">Review and copy the suggested response below:</div>
                </div>
                """, unsafe_allow_html=True)
                
                if suggested_reply_text == "No reply recommended.":
                    st.info(suggested_reply_text)
                else:
                    st.code(suggested_reply_text, language="text")
                    
                workflow_html = """<div style="margin-top: 2.5rem;">
<h4 style="margin-bottom: 1.5rem;">What happens next?</h4>
<div class="workflow-container">
<div class="workflow-line"></div>
<div class="workflow-step">
<div class="step-circle" style="background-color: #38bdf8; color: #0f172a;">1</div>
<div style="color: #e2e8f0; font-weight: 600; font-size: 0.9rem;">Triage</div>
<div class="text-muted text-xs">Categorized by AI</div>
</div>
<div class="workflow-step">
<div class="step-circle" style="background-color: #1e293b; color: #94a3b8;">2</div>
<div style="color: #e2e8f0; font-weight: 600; font-size: 0.9rem;">Review</div>
<div class="text-muted text-xs">Analyst verifies</div>
</div>
<div class="workflow-step">
<div class="step-circle" style="background-color: #1e293b; color: #94a3b8;">3</div>
<div style="color: #e2e8f0; font-weight: 600; font-size: 0.9rem;">Respond</div>
<div class="text-muted text-xs">Team takes action</div>
</div>
<div class="workflow-step">
<div class="step-circle" style="background-color: #1e293b; color: #94a3b8;">4</div>
<div style="color: #e2e8f0; font-weight: 600; font-size: 0.9rem;">Resolve</div>
<div class="text-muted text-xs">Incident tracked</div>
</div>
</div>
</div>"""
                st.markdown(workflow_html, unsafe_allow_html=True)
        elif not analyze_btn or not email_text.strip():
            st.info("Awaiting email input. Paste an email in the left panel and click 'Analyze Email' to view the triage results.")
            
    elif app_mode == "Batch Analysis":
        st.markdown("### 📊 Batch Analysis Dashboard")
        
        if "batch_result_df" not in st.session_state:
            st.session_state.batch_result_df = None
            
        if uploaded_file is not None and "uploaded_df" in st.session_state and isinstance(st.session_state.uploaded_df, pd.DataFrame) and not st.session_state.uploaded_df.empty:
            # Show preview
            st.markdown("#### Data Preview")
            df = st.session_state.uploaded_df
            st.markdown(df.head(5).to_html(index=False), unsafe_allow_html=True)
            
            if batch_btn:
                if "email" in df.columns:
                    with st.spinner("Processing batch using Gemini API... This may take a moment."):
                        processed_df = process_batch(df.copy())
                        st.session_state.batch_result_df = processed_df
                else:
                    st.error("Missing 'email' column.")
                    
            if st.session_state.batch_result_df is not None:
                st.markdown("""
                <div style="background-color: #064e3b; color: #34d399; padding: 12px 16px; border-radius: 6px; margin-bottom: 1.5rem; border: 1px solid #059669; display: flex; align-items: center; font-size: 0.95rem;">
                    <span style="font-size: 1.2rem; margin-right: 10px;">✅</span>
                    <strong>Batch Processing Complete:</strong>&nbsp;All rows analyzed.
                </div>
                """, unsafe_allow_html=True)
                
                st.markdown("#### Analysis Results")
                st.markdown(st.session_state.batch_result_df.to_html(index=False), unsafe_allow_html=True)
                
                # Download button
                csv = st.session_state.batch_result_df.to_csv(index=False)
                st.download_button(
                    label="Download Results CSV",
                    data=csv,
                    file_name="cybermail_batch_results.csv",
                    mime="text/csv"
                )
        else:
            st.info("Upload a CSV file in the left panel to begin batch processing.")
