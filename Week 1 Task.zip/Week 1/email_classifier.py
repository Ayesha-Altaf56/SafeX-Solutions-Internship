import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


def load_data(path="emails.csv"):
    """Load the email dataset and combine subject + body into one text field."""
    df = pd.read_csv(path)
    df["text"] = df["subject"].fillna("") + " " + df["body"].fillna("")
    return df


def train_model(df):
    """Split the data, vectorize it with TF-IDF, and train a Naive Bayes model."""
    X = df["text"]
    y = df["label"]

    # 80/20 train/test split, stratified to keep class balance consistent
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Convert text into TF-IDF numerical features
    vectorizer = TfidfVectorizer(stop_words="english")
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    # Train the Multinomial Naive Bayes classifier
    model = MultinomialNB()
    model.fit(X_train_tfidf, y_train)

    return model, vectorizer, X_test_tfidf, y_test


def evaluate_model(model, X_test_tfidf, y_test):
    """Print accuracy, classification report, and confusion matrix."""
    y_pred = model.predict(X_test_tfidf)

    print("\n=== Accuracy ===")
    print(f"{accuracy_score(y_test, y_pred):.2%}")

    print("\n=== Classification Report ===")
    print(classification_report(y_test, y_pred, zero_division=0))

    print("=== Confusion Matrix ===")
    labels = sorted(y_test.unique())
    cm = confusion_matrix(y_test, y_pred, labels=labels)
    cm_df = pd.DataFrame(cm, index=labels, columns=labels)
    print(cm_df)


def predict_new_email(model, vectorizer):
    """Ask the user for a subject and body, then predict the email category."""
    print("\n=== Try Your Own Email ===")
    subject = input("Enter subject: ")
    body = input("Enter body: ")

    text = subject + " " + body
    text_tfidf = vectorizer.transform([text])
    prediction = model.predict(text_tfidf)[0]

    print(f"\nPredicted category: {prediction.capitalize()}")


def main():
    # 1. Load data
    df = load_data("emails.csv")

    # 2. Train model
    model, vectorizer, X_test_tfidf, y_test = train_model(df)

    # 3. Evaluate model
    evaluate_model(model, X_test_tfidf, y_test)

    # 4. Predict a new email entered by the user
    predict_new_email(model, vectorizer)


if __name__ == "__main__":
    main()
