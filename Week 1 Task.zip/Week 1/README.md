# Email Triage Classifier Prototype

A machine learning prototype that automatically classifies incoming emails into **Spam**, **Lead**, or **Support** categories, helping teams route messages to the right destination without manual triage.

## Project Overview

Manually sorting incoming emails into spam, sales leads, and support requests is time-consuming and error-prone at scale. This project builds a prototype text classifier that reads an email's subject and body and predicts which of the three categories it belongs to. It is designed as a lightweight, easy-to-understand baseline that can be extended with more data and more advanced models over time.

## Features

- Classifies emails into three categories: **Spam**, **Lead**, and **Support**
- Combines subject and body text into a single feature for classification
- Converts raw text into numerical features using TF-IDF
- Trains a Multinomial Naive Bayes model, a fast and effective baseline for text classification
- Evaluates performance with accuracy, a full classification report, and a confusion matrix
- Includes an interactive mode to classify a new, user-entered email on the spot
- Available as both a standalone Python script and a documented Jupyter notebook

## Dataset Description

The dataset (`emails.csv`) contains labeled example emails with the following columns:

| Column | Description |
|---|---|
| `subject` | The subject line of the email |
| `body` | The main text content of the email |
| `label` | The category: `spam`, `lead`, or `support` |

The dataset is a small, hand-curated set of representative emails covering common patterns for each category — promotional/phishing language for spam, sales and pricing inquiries for leads, and account/product issues for support. It is intended as a prototype dataset and is designed to grow over time.

## Technologies Used

- **Python** — core programming language
- **Pandas** — data loading and manipulation
- **Scikit-learn** — machine learning pipeline (TF-IDF, Naive Bayes, evaluation metrics)
- **TF-IDF Vectorizer** — converts email text into numerical features
- **Multinomial Naive Bayes** — classification algorithm

## Installation

1. Clone or download this project.
2. Install the required dependencies:

```bash
pip install pandas scikit-learn
```

(If using the notebook version with visualizations, also install `matplotlib` and `seaborn`:)

```bash
pip install matplotlib seaborn
```

## How to Run

Make sure `emails.csv` is in the same directory as the script or notebook.

**Run the script:**

```bash
python3 email_classifier.py
```

The script will:
1. Load and preprocess the data
2. Train the classifier
3. Print accuracy, a classification report, and a confusion matrix
4. Prompt you to enter a new email's subject and body, then predict its category

**Run the notebook:**

Open `email_classifier.ipynb` in Jupyter and run all cells in order.

## Project Structure

```
.
├── email_classifier.py       # Standalone script version
├── email_classifier.ipynb    # Notebook version with explanations and visualizations
├── emails.csv                 # Labeled email dataset
└── README.md                  # Project documentation
```

## Results

On a held-out test set, the model achieves accuracy in the range of **60–80%**, depending on the train/test split, reflecting the small size of the current prototype dataset. Spam emails are generally classified most reliably due to distinctive promotional language, while Lead and Support emails are occasionally confused with each other since they can share similar general business vocabulary.

## Future Improvements

- Expand the dataset with more labeled examples per category
- Add more realistic, longer email samples closer to real-world messages
- Include harder, ambiguous examples to better distinguish Lead from Support
- Incorporate additional features such as sender domain, links, or attachments
- Experiment with more advanced models (Logistic Regression, SVM, or transformer-based embeddings)
- Build a simple API or web interface for real-time email classification

## Author

Ayesha Altaf